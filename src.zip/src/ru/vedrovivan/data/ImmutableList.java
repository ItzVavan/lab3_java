package ru.vedrovivan.data;

import java.util.Arrays;

/**
 * Задание 2.1
 */
public final class ImmutableList {
    private final int[] values;


    public ImmutableList(int... values) {
        if (values == null) {
            this.values = new int[0];
        } else {
            this.values = Arrays.copyOf(values, values.length);
        }
    }

    // Конструктор 3: на основе другого списка
    public ImmutableList(ImmutableList other) {
        if (other == null || other.values == null) {
            this.values = new int[0];
        } else {
            this.values = Arrays.copyOf(other.values, other.values.length);
        }
    }

    // Текущий размер
    public int size() {
        return values.length;
    }

    // Проверка на пустоту
    public boolean isEmpty() {
        return values.length == 0;
    }

    // Получение значения из позиции index (0 .. size - 1)
    public int get(int index) {
        checkIndex(index);
        return values[index];
    }

    // Замена значения: возвращает новый список, исходный не изменяется
    public ImmutableList set(int index, int newValue) {
        checkIndex(index);
        int[] copy = Arrays.copyOf(values, values.length);
        copy[index] = newValue;
        return new ImmutableList(copy);
    }

    // Получение данных в виде обычного массива
    public int[] toArray() {
        return Arrays.copyOf(values, values.length);
    }

    // Приведение к строке вида "[1, 2, 3]"
    @Override
    public String toString() {
        return Arrays.toString(values);
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= values.length) {
            throw new IndexOutOfBoundsException(
                "Индекс " + index + " выходит за границы диапазона [0, " + (values.length - 1) + "]"
            );
        }
    }
}