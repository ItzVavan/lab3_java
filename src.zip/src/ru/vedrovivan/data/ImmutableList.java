package ru.vedrovivan.data;

public class ImmutableList {
    private final int[] values;

    // Конструктор по массиву
    public ImmutableList(int[] values) {
        if (values == null) {
            this.values = new int[0];
        } else {
            this.values = new int[values.length];
            for (int i = 0; i < values.length; i++) {
                this.values[i] = values[i];
            }
        }
    }

    // Конструктор по другому списку
    public ImmutableList(ImmutableList other) {
        this(other != null ? other.values : new int[0]);
    }

    public int get(int index) {
        if (index < 0 || index >= values.length) {
            throw new IllegalArgumentException("Индекс за пределами диапазона");
        }
        return values[index];
    }

    // Возвращает новый список с измененным значением (неизменяемый список)
    public ImmutableList set(int index, int newValue) {
        if (index < 0 || index >= values.length) {
            throw new IllegalArgumentException("Индекс за пределами диапазона");
        }
        int[] copy = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            copy[i] = values[i];
        }
        copy[index] = newValue;
        return new ImmutableList(copy);
    }

    public boolean isEmpty() {
        return values.length == 0;
    }

    public int size() {
        return values.length;
    }

    public int[] toArray() {
        int[] copy = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            copy[i] = values[i];
        }
        return copy;
    }

    @Override
    public String toString() {
        String res = "[";
        for (int i = 0; i < values.length; i++) {
            res += values[i];
            if (i < values.length - 1) {
                res += ", ";
            }
        }
        res += "]";
        return res;
    }
}