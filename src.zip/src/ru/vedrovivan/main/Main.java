package ru.vedrovivan.main;

import static java.lang.Integer.parseInt;
import static java.lang.Math.pow;

import java.util.Arrays;
import java.util.Scanner;
import ru.vedrovivan.geometry.Point;
import ru.vedrovivan.geometry.Point3D;
import ru.vedrovivan.geometry.Line;
import ru.vedrovivan.geometry.Polyline;
import ru.vedrovivan.geometry.Square;
import ru.vedrovivan.geometry.AttributedPoint;
import ru.vedrovivan.data.ImmutableList;
import ru.vedrovivan.math.Fraction;

public class Main {

    // Задание 5.1: метод принимает набор Number и считает вещественную сумму
    public static double sum(Number[] numbers) {
        double total = 0.0;
        for (Number n : numbers) {
            total += n.doubleValue();
        }
        return total;
    }

    // Задание 7.3: статический импорт pow и parseInt
    public static double power(String xStr, String yStr) {
        int x = parseInt(xStr);
        int y = parseInt(yStr);
        return pow(x, y);
    }

    // Вспомогательный безопасный ввод целого числа
    private static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода: введите корректное целое число.");
            }
        }
    }

    // Ввод целого числа с проверкой на неотрицательность
    private static int readNonNegativeInt(Scanner scanner, String prompt) {
        while (true) {
            int value = readInt(scanner, prompt);
            if (value >= 0) {
                return value;
            }
            System.out.println("Ошибка: число не может быть отрицательным.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Лабораторная работа №3 (Вариант 1) ===");

        // --- ДЕМОНСТРАЦИЯ 7.3 ---
        System.out.println("\n--- [Задание 7.3: Возведение в степень] ---");
        if (args.length >= 2) {
            System.out.println("Аргументы из командной строки: " + args[0] + " ^ " + args[1] + " = " + power(args[0], args[1]));
        } else {
            System.out.println("Аргументы командной строки не переданы. Введите вручную:");
            int x = readInt(scanner, "Введите основание X: ");
            int y = readInt(scanner, "Введите показатель Y: ");
            System.out.println("Результат: " + power(String.valueOf(x), String.valueOf(y)));
        }

        // --- ДЕМОНСТРАЦИЯ 1.6, 6.3, 8.5 (Линии) ---
        System.out.println("\n--- [Задания 1.6, 6.3, 8.5: Линия, equals, clone] ---");
        int x1 = readInt(scanner, "Линия 1, начало X: ");
        int y1 = readInt(scanner, "Линия 1, начало Y: ");
        int x2 = readInt(scanner, "Линия 1, конец X: ");
        int y2 = readInt(scanner, "Линия 1, конец Y: ");

        Line line1 = new Line(new Point(x1, y1), new Point(x2, y2));
        Line line2 = line1.clone(); // Задание 8.5

        System.out.println("Создана line1: " + line1);
        System.out.println("Создана копия line2: " + line2);
        System.out.println("line1.equals(line2): " + line1.equals(line2)); // Задание 6.3

        line2.setStart(new Point(line2.getStart().getX() + 10, line2.getStart().getY() + 10));
        System.out.println("После изменения точки в line2:");
        System.out.println("line1: " + line1);
        System.out.println("line2: " + line2);
        System.out.println("line1.equals(line2): " + line1.equals(line2));

        // --- ДЕМОНСТРАЦИЯ 1.12 (Квадрат) ---
        System.out.println("\n--- [Задание 1.12: Квадрат и Ломаная] ---");
        int sqX = readInt(scanner, "Введите X верхнего левого угла квадрата: ");
        int sqY = readInt(scanner, "Введите Y верхнего левого угла квадрата: ");
        int sqSide = readInt(scanner, "Введите сторону квадрата: ");
        Square sq = new Square(sqX, sqY, sqSide);
        System.out.println("Создан: " + sq);
        Polyline poly = sq.getPolyline();
        System.out.println("Ломаная линия: " + poly);
        System.out.println("Длина ломаной квадрата: " + poly.getLength());
        poly.setPoint(3, new Point(15, 25));
        System.out.println("После сдвига точки: " + poly);
        System.out.println("Новая длина ломаной: " + poly.getLength());

        // --- ДЕМОНСТРАЦИЯ 2.1 (Неизменяемый список значений) ---
        System.out.println("\n--- [Задание 2.1: НеизменяемыйСписокЗначений] ---");
        int size = readNonNegativeInt(scanner, "Введите количество элементов для списка: ");
        int[] inputArr = new int[size];
        for (int i = 0; i < size; i++) {
            inputArr[i] = readInt(scanner, "Элемент [" + i + "]: ");
        }

        // 1. Создание через массив
        ImmutableList list1 = new ImmutableList(inputArr);
        System.out.println("Создан list1 (из массива): " + list1);
        System.out.println("Размер: " + list1.size() + ", Пуст ли список: " + list1.isEmpty());

        // 2. Создание через varargs (независимые значения через запятую)
        ImmutableList listVarargs = new ImmutableList(100, 200, 300);
        System.out.println("Создан список через varargs (100, 200, 300): " + listVarargs);

        // 3. Создание копии другого списка
        ImmutableList listCopy = new ImmutableList(list1);
        System.out.println("Создана копия list1 в listCopy: " + listCopy);

        // 4. Получение значения по индексу с клавиатуры
        if (!list1.isEmpty()) {
            int getIdx = readInt(scanner, "Введите индекс для получения значения: ");
            try {
                System.out.println("Значение по индексу " + getIdx + ": " + list1.get(getIdx));
            } catch (IndexOutOfBoundsException e) {
                System.out.println("Поймана ошибка: " + e.getMessage());
            }

            // 5. Замена значения
            int setIdx = readInt(scanner, "Введите индекс для замены значения: ");
            int newVal = readInt(scanner, "Введите новое значение: ");
            try {
                ImmutableList replaced = list1.set(setIdx, newVal);
                System.out.println("Исходный list1 остался неизменным: " + list1);
                System.out.println("Новый список с замененным значением: " + replaced);
            } catch (IndexOutOfBoundsException e) {
                System.out.println("Поймана ошибка: " + e.getMessage());
            }

            // 6. Получение в виде стандартного массива
            int[] rawCopy = list1.toArray();
            System.out.println("Получен стандартный массив toArray(): " + Arrays.toString(rawCopy));
        }

        // --- ДЕМОНСТРАЦИЯ 3.5 (Трехмерная точка) ---
        System.out.println("\n--- [Задание 3.5: Трехмерная точка] ---");
        int p3x = readInt(scanner, "3D точка X: ");
        int p3y = readInt(scanner, "3D точка Y: ");
        int p3z = readInt(scanner, "3D точка Z: ");
        Point3D p3d = new Point3D(p3x, p3y, p3z);
        System.out.println("Создана 3D точка: " + p3d);

        // --- ДЕМОНСТРАЦИЯ 4.5 (Точки с характеристиками) ---
        System.out.println("\n--- [Задание 4.5: Точки с характеристиками] ---");
        AttributedPoint ap1 = new AttributedPoint(new int[]{3}, "красный", null);
        AttributedPoint ap2 = new AttributedPoint(new int[]{4, 2, 5}, null, "11:00");
        AttributedPoint ap3 = new AttributedPoint(new int[]{7, 7}, "желтый", "15:35");
        System.out.println(ap1);
        System.out.println(ap2);
        System.out.println(ap3);

        // --- ДЕМОНСТРАЦИЯ 5.1 (Полиморфное сложение) ---
        System.out.println("\n--- [Задание 5.1: Сложение] ---");
        // 1) 2 + 3/5 + 2.3
        Number[] sum1 = { 2, new Fraction(3, 5), 2.3 };
        System.out.println("2 + 3/5 + 2.3 = " + sum(sum1));

        // 2) 3.6 + 49/12 + 3 + 3/2
        Number[] sum2 = { 3.6, new Fraction(49, 12), 3, new Fraction(3, 2) };
        System.out.println("3.6 + 49/12 + 3 + 3/2 = " + sum(sum2));

        // 3) 1/3 + 1
        Number[] sum3 = { new Fraction(1, 3), 1 };
        System.out.println("1/3 + 1 = " + sum(sum3));

        System.out.println("\n=== Работа программы успешно завершена ===");
    }
}