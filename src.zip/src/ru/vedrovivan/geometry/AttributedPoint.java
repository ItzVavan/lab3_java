package ru.vedrovivan.geometry;

// Класс координаты точки
public class AttributedPoint {
    private int[] coordinates;
    private String color;
    private String time;

    public AttributedPoint(int[] coordinates, String color, String time) {
        this.coordinates = coordinates != null ? coordinates.clone() : new int[0];
        this.color = color;
        this.time = time;
    }

    public int[] getCoordinates() {
        return coordinates.clone();
    }

    public String getColor() {
        return color;
    }

    public String getTime() {
        return time;
    }

    @Override
    public String toString() {
        String res = "Точка в координате (";
        for (int i = 0; i < coordinates.length; i++) {
            res += coordinates[i];
            if (i < coordinates.length - 1) res += ",";
        }
        res += ")";
        if (color != null) res += ", цвет: " + color;
        if (time != null) res += " в " + time;
        return res;
    }
}