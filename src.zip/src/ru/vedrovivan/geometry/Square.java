package ru.vedrovivan.geometry;

public class Square {
    private Point topLeft;
    private int side;

    public Square(Point topLeft, int side) {
        if (topLeft == null) {
            throw new IllegalArgumentException("Точка не может быть null");
        }
        if (side <= 0) {
            throw new IllegalArgumentException("Длина стороны должна быть положительной");
        }
        this.topLeft = topLeft.clone();
        this.side = side;
    }

    public Square(int x, int y, int side) {
        this(new Point(x, y), side);
    }

    public Point getTopLeft() {
        return topLeft.clone();
    }

    public int getSide() {
        return side;
    }

    public void setSide(int side) {
        if (side <= 0) {
            throw new IllegalArgumentException("Длина стороны должна быть положительной");
        }
        this.side = side;
    }

    public Polyline getPolyline() {
        Point p1 = topLeft.clone();
        Point p2 = new Point(topLeft.getX() + side, topLeft.getY());
        Point p3 = new Point(topLeft.getX() + side, topLeft.getY() - side);
        Point p4 = new Point(topLeft.getX(), topLeft.getY() - side);
        return new Polyline(new Point[]{p1, p2, p3, p4});
    }

    @Override
    public String toString() {
        return "Квадрат в точке " + topLeft + " со стороной " + side;
    }
}