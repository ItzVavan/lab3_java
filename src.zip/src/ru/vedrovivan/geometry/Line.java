package ru.vedrovivan.geometry;

public class Line {
    private Point start;
    private Point end;

    public Line(Point start, Point end) {
        if (start == null || end == null) {
            throw new IllegalArgumentException("Точки не могут быть null");
        }
        // Гарантируем, что линии не ссылаются на переданные объекты снаружи
        this.start = start.clone();
        this.end = end.clone();
    }

    public Line(int x1, int y1, int x2, int y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
    }

    public Point getStart() {
        return start.clone();
    }

    public void setStart(Point start) {
        if (start == null) {
            throw new IllegalArgumentException("Точка начала не может быть null");
        }
        this.start = start.clone();
    }

    public Point getEnd() {
        return end.clone();
    }

    public void setEnd(Point end) {
        if (end == null) {
            throw new IllegalArgumentException("Точка конца не может быть null");
        }
        this.end = end.clone();
    }

    // Задание 6.3
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Line other = (Line) obj;
        return this.start.equals(other.start) && this.end.equals(other.end);
    }

    // Задание 8.5
    @Override
    public Line clone() {
        return new Line(this.start, this.end);
    }

    @Override
    public String toString() {
        return "Линия от " + start + " до " + end;
    }
}