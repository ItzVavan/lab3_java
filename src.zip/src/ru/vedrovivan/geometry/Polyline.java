package ru.vedrovivan.geometry;

public class Polyline {
    private Point[] points;

    public Polyline(Point[] points) {
        if (points == null) {
            this.points = new Point[0];
        } else {
            this.points = new Point[points.length];
            for (int i = 0; i < points.length; i++) {
                this.points[i] = points[i].clone();
            }
        }
    }

    public Point[] getPoints() {
        return points;
    }

    public void setPoint(int index, Point point) {
        if (index < 0 || index >= points.length) {
            throw new IllegalArgumentException("Некорректный индекс точки");
        }
        this.points[index] = point.clone();
    }

    public double getLength() {
        double length = 0;
        for (int i = 0; i < points.length - 1; i++) {
            int dx = points[i + 1].getX() - points[i].getX();
            int dy = points[i + 1].getY() - points[i].getY();
            length += Math.sqrt(dx * dx + dy * dy);
        }
        return length;
    }

    @Override
    public String toString() {
        String res = "Ломаная линия [";
        for (int i = 0; i < points.length; i++) {
            res += points[i].toString();
            if (i < points.length - 1) {
                res += ", ";
            }
        }
        res += "]";
        return res;
    }
}